#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

const int buzzerPin = 8;
const float threshold = 35.0;

void setup() {
  dht.begin();

  lcd.init();
  lcd.backlight();

  pinMode(buzzerPin, OUTPUT);

  lcd.setCursor(0, 0);
  lcd.print("Digital Thermo");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");
  delay(2000);

  lcd.clear();
}

void loop() {
  float temp = dht.readTemperature();

  if (isnan(temp)) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Sensor Error");
    noTone(buzzerPin);
    delay(1000);
    return;
  }

  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temp);
  lcd.print((char)223);
  lcd.print("C   ");

  if (temp > threshold) {
    lcd.setCursor(0, 1);
    lcd.print("HIGH TEMP ALERT");

    tone(buzzerPin, 1000);   // buzzer ON
  }
  else {
    lcd.setCursor(0, 1);
    lcd.print("Normal Temp    ");

    noTone(buzzerPin);       // buzzer OFF
  }

  delay(500);
}